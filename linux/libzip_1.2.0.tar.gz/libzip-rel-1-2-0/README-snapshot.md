To build libzip from the repository using autotools, you need to
install autoconf, automake, and libtool; then run
> autoreconf -fi

Afterwards you can run configure as usual.

Alternatively, use cmake.
